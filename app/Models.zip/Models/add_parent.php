<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class add_parent extends Model
{
    //
}
